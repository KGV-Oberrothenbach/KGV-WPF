@echo off
setlocal EnableExtensions

REM KGV Oberrothenbach - Zertifikat auf Zielrechner installieren
REM Erwartet die Datei kgv-codesign.cer im gleichen Ordner wie diese Batch.

cd /d "%~dp0"
set "CERT_FILE=%~dp0kgv-codesign.cer"

echo ================================================
echo KGV Oberrothenbach - Zertifikat installieren
echo ================================================
echo.

if not exist "%CERT_FILE%" (
  echo FEHLER: Zertifikatsdatei nicht gefunden:
  echo %CERT_FILE%
  echo.
  echo Lege die Datei "kgv-codesign.cer" in denselben Ordner wie diese Batch.
  pause
  exit /b 1
)

net session >nul 2>&1
if errorlevel 1 (
  echo Starte neu mit Administratorrechten...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo Installiere Zertifikat in "Vertrauenswuerdige Stammzertifizierungsstellen"...
certutil -f -addstore "Root" "%CERT_FILE%"
if errorlevel 1 (
  echo.
  echo FEHLER beim Import in Root.
  pause
  exit /b 1
)

echo.
echo Installiere Zertifikat in "Vertrauenswuerdige Herausgeber"...
certutil -f -addstore "TrustedPublisher" "%CERT_FILE%"
if errorlevel 1 (
  echo.
  echo FEHLER beim Import in TrustedPublisher.
  pause
  exit /b 1
)

echo.
echo Zertifikat wurde erfolgreich installiert.
echo Du kannst die KGV-App jetzt auf diesem Rechner mit dem importierten Zertifikat ausfuehren.
echo.
pause
exit /b 0
