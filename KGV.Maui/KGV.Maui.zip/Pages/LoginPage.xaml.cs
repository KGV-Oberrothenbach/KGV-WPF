using KGV.Core.Interfaces;
using KGV.Infrastructure.Services;
using KGV.Maui.State;
using System;
using System.Linq;

namespace KGV.Maui.Pages;

public class LoginPage : ContentPage
{
    private readonly IAuthService _authService;
    private readonly IUserContextService _userContextService;
    private readonly UserContextState _userContextState;
    private readonly AppShell _appShell;

    private readonly Entry _emailEntry;
    private readonly Entry _passwordEntry;
    private readonly Label _statusLabel;

    public LoginPage(
        IAuthService authService,
        IUserContextService userContextService,
        UserContextState userContextState,
        AppShell appShell)
    {
        _authService = authService;
        _userContextService = userContextService;
        _userContextState = userContextState;
        _appShell = appShell;

        Title = "Login";

        _emailEntry = new Entry { Placeholder = "E-Mail", Keyboard = Keyboard.Email };
        _passwordEntry = new Entry { Placeholder = "Passwort", IsPassword = true };
        _statusLabel = new Label { TextColor = Colors.Red };

        var loginButton = new Button { Text = "Anmelden" };
        loginButton.Clicked += OnLoginClicked;

        Content = new VerticalStackLayout
        {
            Padding = 24,
            Spacing = 12,
            Children =
            {
                new Label { Text = "Login", FontSize = 24, FontAttributes = FontAttributes.Bold },
                _emailEntry,
                _passwordEntry,
                loginButton,
                _statusLabel
            }
        };
    }

    private async void OnLoginClicked(object? sender, EventArgs e)
    {
        _statusLabel.Text = string.Empty;

        var email = (_emailEntry.Text ?? string.Empty).Trim();
        var password = _passwordEntry.Text ?? string.Empty;

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            _statusLabel.Text = "Bitte E-Mail und Passwort eingeben.";
            return;
        }

        try
        {
            var ok = await _authService.LoginAsync(email, password);
            if (!ok)
            {
                _statusLabel.Text = "Login fehlgeschlagen.";
                return;
            }

            if (string.IsNullOrWhiteSpace(_authService.CurrentUserId) || !Guid.TryParse(_authService.CurrentUserId, out var userId))
            {
                _statusLabel.Text = "Login ok, aber UserId ist ungültig.";
                return;
            }

            var userContext = await _userContextService.GetUserContextAsync(userId);
            _userContextState.CurrentUserContext = userContext;

            if (userContext.Role == KGV.Core.Security.UserRole.User && userContext.MitgliedId == null)
            {
                _statusLabel.Text = "Account ist keinem Mitglied zugeordnet.";
                return;
            }

            _appShell.BuildMenu(userContext);
            var window = Application.Current?.Windows?.FirstOrDefault();
            if (window != null)
                window.Page = _appShell;
        }
        catch (Exception ex)
        {
            _statusLabel.Text = ex.Message;
        }
    }
}
