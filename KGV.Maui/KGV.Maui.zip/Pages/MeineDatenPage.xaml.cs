namespace KGV.Maui.Pages;

public class MeineDatenPage : ContentPage
{
    public MeineDatenPage()
    {
        Title = "Meine Daten";

        Content = new VerticalStackLayout
        {
            Padding = 24,
            Spacing = 12,
            Children =
            {
                new Label { Text = "Meine Daten", FontSize = 24, FontAttributes = FontAttributes.Bold },
                new Label { Text = "Platzhalter" }
            }
        };
    }
}
