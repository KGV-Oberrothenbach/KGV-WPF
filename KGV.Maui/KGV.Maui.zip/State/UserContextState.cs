using KGV.Core.Security;

namespace KGV.Maui.State;

public sealed class UserContextState : IUserContextAccessor
{
    public UserContext? CurrentUserContext { get; set; }
}
