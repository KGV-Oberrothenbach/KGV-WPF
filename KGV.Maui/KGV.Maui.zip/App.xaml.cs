using KGV.Maui.Pages;

namespace KGV.Maui;

public class App : Application
{
    private readonly LoginPage _loginPage;

    public App(LoginPage loginPage)
    {
        _loginPage = loginPage;
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var root = new NavigationPage(_loginPage);
        return new Window(root);
    }
}
