using KGV.Core.Security;
using KGV.Infrastructure.DependencyInjection;
using KGV.Maui.Pages;
using KGV.Maui.State;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KGV.Maui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>();

#if DEBUG
        builder.Logging.AddDebug();
#endif

        // Use the same appsettings.json as the WPF app.
        // For Android this must be packaged as an app asset (see `KGV.Maui.csproj`).
        TryAddAppSettings(builder.Configuration);

        builder.Services.AddSingleton<UserContextState>();
        builder.Services.AddSingleton<IUserContextAccessor>(sp => sp.GetRequiredService<UserContextState>());

        builder.Services.AddKgvServices(builder.Configuration);

        builder.Services.AddTransient<LoginPage>();
        builder.Services.AddTransient<HomePage>();
        builder.Services.AddTransient<MeineDatenPage>();
        builder.Services.AddTransient<DokumentePage>();

        builder.Services.AddSingleton<AppShell>();

        return builder.Build();
    }

    private static void TryAddAppSettings(IConfigurationBuilder configuration)
    {
        try
        {
            using var stream = FileSystem.OpenAppPackageFileAsync("appsettings.json").GetAwaiter().GetResult();
            configuration.AddJsonStream(stream);
        }
        catch
        {
        }
    }
}
