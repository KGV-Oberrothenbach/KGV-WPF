using KGV.Core.Security;
using KGV.Maui.Pages;

namespace KGV.Maui;

public class AppShell : Shell
{
    public AppShell()
    {
        FlyoutBehavior = FlyoutBehavior.Disabled;
    }

    public void BuildMenu(UserContext userContext)
    {
        Items.Clear();

        FlyoutBehavior = FlyoutBehavior.Flyout;

        // Always show Home
        Items.Add(new FlyoutItem
        {
            Title = "Home",
            Items =
            {
                new ShellContent
                {
                    Title = "Home",
                    ContentTemplate = new DataTemplate(typeof(HomePage))
                }
            }
        });

        if (userContext.Has(PermissionFlags.CanSeeOwnDataOnly))
        {
            Items.Add(new FlyoutItem
            {
                Title = "Meine Daten",
                Items =
                {
                    new ShellContent
                    {
                        Title = "Meine Daten",
                        ContentTemplate = new DataTemplate(typeof(MeineDatenPage))
                    }
                }
            });
        }

        if (userContext.Has(PermissionFlags.CanManageDocuments))
        {
            Items.Add(new FlyoutItem
            {
                Title = "Dokumente",
                Items =
                {
                    new ShellContent
                    {
                        Title = "Dokumente",
                        ContentTemplate = new DataTemplate(typeof(DokumentePage))
                    }
                }
            });
        }
    }
}
